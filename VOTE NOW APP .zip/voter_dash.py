from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import sqlite3
import os


# Function to vote for a candidate
def vote(candidate_id, user_id):
    try:
        conn = sqlite3.connect('vo_system.db')
        cursor = conn.cursor()

        # Check if the user has already voted
        cursor.execute("SELECT * FROM votes WHERE user_id=?", (user_id,))
        if cursor.fetchone():
            messagebox.showerror("Error", "You have already voted!")
            return

        # Cast the vote
        cursor.execute("UPDATE candidates SET votes = votes + 1 WHERE id=?", (candidate_id,))
        cursor.execute("INSERT INTO votes (user_id, candidate_id) VALUES (?, ?)", (user_id, candidate_id))
        conn.commit()
        messagebox.showinfo("Success", "Your vote has been submitted!")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")
    finally:
        conn.close()

# Voter dashboard
def voter_dashboard(user_id):
    root = Tk()
    root.title("Voter Dashboard")
    root.geometry("950x500")
    root.resizable(False, False)
    root.configure(bg='#6495ED')

    def open_page(page_script):
        root.destroy()  # Close the current window
        os.system(f'python {page_script}')  # Not ideal for Tkinter, ideally use a new window or frame

    # Configure ttk styles
    style = ttk.Style()
    style.theme_use("clam")
    style.configure(
        "Treeview",
        font=("Ubuntu Mono", 12),
        foreground="#333333",
        rowheight=25,
        background="#eeeeee",
        fieldbackground="#eeeeee"
    )
    # Button style
    style.configure("SoftRound.TButton",
                    background="#483D8B",
                    foreground="white",
                    font=("Ubuntu Mono", 12),
                    padding=5,
                    width=15,
                    borderwidth=2,
                    relief="flat")
    style.map("SoftRound.TButton",
              background=[("active", "#005a9e")])

    # Header label style
    style.configure("Header.TLabel",
                    font=("Ubuntu Mono", 20, "bold"),
                    background='#6495ED',
                    foreground="#483D8B",
                    padding=5)

    # Label style
    style.configure("Label.TLabel",
                    font=("Ubuntu Mono", 12),
                    background="#6495ED",
                    foreground="#483D8B",
                    padding=5)
    style.configure("Treeview.Heading", font=("Ubuntu Mono", 12, "bold"), background="#6495ED", foreground="#f9f9f9")
    ttk.Label(root, text="Welcome to the Voter Dashboard", style="Header.TLabel").pack(pady=10)

    try:
        conn = sqlite3.connect('vo_system.db')
        cursor = conn.cursor()

        # Fetch voter's district
        cursor.execute("SELECT district FROM users WHERE id=?", (user_id,))
        voter_district = cursor.fetchone()
        if not voter_district:
            messagebox.showerror("Error", "Voter district not found!")
            conn.close()
            return
        voter_district = voter_district[0]

        # Fetch candidates from the same district
        cursor.execute("SELECT id, name, party, district FROM candidates WHERE district=?", (voter_district,))
        candidates = cursor.fetchall()
        conn.close()

        if not candidates:
            messagebox.showinfo("Info", "No candidates available in your district.")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to fetch candidates: {str(e)}")
        return

    ttk.Label(root, text="Candidates", style="Header.TLabel").pack(pady=10)
    for candidate in candidates:
        frame = Frame(root, bg='#6495ED')
        frame.pack(pady=5, padx=10, fill=X)
        ttk.Label(frame, text=f"{candidate[1]} ({candidate[2]}, {candidate[3]})", style="Label.TLabel").pack(side=LEFT, padx=10)
        ttk.Button(frame, text="Vote", style="SoftRound.TButton", command=lambda c=candidate: vote(c[0], user_id)).pack(side=RIGHT, padx=10)

    # Function to update user profile
    def update_user_profile(user_id):
        def save_changes():
            new_password = entry_password.get()
            new_email = entry_email.get()
            new_district = combo_district.get()

            try:
                conn = sqlite3.connect('vo_system.db')
                cursor = conn.cursor()

                # Update password if provided
                if new_password:
                    cursor.execute("UPDATE users SET password=? WHERE id=?", (new_password, user_id))

                # Update email if provided
                if new_email:
                    cursor.execute("UPDATE users SET email=? WHERE id=?", (new_email, user_id))

                # Update district if provided
                if new_district:
                    cursor.execute("UPDATE users SET district=? WHERE id=?", (new_district, user_id))

                conn.commit()
                messagebox.showinfo("Success", "Profile updated successfully!")
                update_window.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
            finally:
                conn.close()

        update_window = Toplevel()
        update_window.title("Update Profile")
        update_window.geometry("400x350")
        update_window.configure(bg='#6495ED')

        ttk.Label(update_window, text="Update Profile", style="Header.TLabel").pack(pady=10)

        frame = Frame(update_window, bg='#6495ED')
        frame.pack(pady=10, padx=10, fill=X)

        # Password update
        ttk.Label(frame, text="New Password:", style="Label.TLabel").grid(row=0, column=0, sticky=W, padx=10, pady=5)
        entry_password = Entry(frame, show="*", width=30)
        entry_password.grid(row=0, column=1, padx=10, pady=5)

        # Email update
        ttk.Label(frame, text="New Email:", style="Label.TLabel").grid(row=1, column=0, sticky=W, padx=10, pady=5)
        entry_email = Entry(frame, width=30)
        entry_email.grid(row=1, column=1, padx=10, pady=5)

        # District update with ComboBox
        ttk.Label(frame, text="New District:", style="Label.TLabel").grid(row=2, column=0, sticky=W, padx=10, pady=5)
        combo_district = ttk.Combobox(frame, width=28, state="readonly")
        combo_district['values'] = (
            "Ampara", "Anuradhapura", "Badulla", "Batticaloa", "Colombo", "Galle", "Gampaha", "Hambantota", "Jaffna",
            "Kalutara", "Kandy", "Kegalle", "Kilinochchi", "Kurunegala", "Mannar", "Matale", "Matara", "Monaragala",
            "Mullaitivu", "Nuwara Eliya", "Polonnaruwa", "Puttalam", "Ratnapura", "Trincomalee", "Vavuniya")
        combo_district.grid(row=2, column=1, padx=10, pady=5)

        # button for update user details
        ttk.Button(update_window, text="Save Changes", style="SoftRound.TButton", command=save_changes).pack(pady=5)

    # View voting results with Treeview
    def view_results():
        try:
            conn = sqlite3.connect('vo_system.db')
            cursor = conn.cursor()
            cursor.execute("SELECT name, party, district, votes FROM candidates")
            results = cursor.fetchall()
            conn.close()

            results_window = Toplevel(root)
            results_window.title("Voting Results")
            results_window.geometry("950x500")
            results_window.configure(bg='#6495ED')
            results_window.resizable(width=False, height=False)

            ttk.Label(results_window, text="Voting Results", style="Header.TLabel").pack(pady=10)

            # Treeview setup
            tree = ttk.Treeview(results_window, columns=("Name", "Party", "District", "Votes"), style='Treeview', show="headings")
            tree.pack(padx=20, pady=20, fill=BOTH, expand=True)

            # Define column headings
            tree.heading("Name", text="Name")
            tree.heading("Party", text="Party")
            tree.heading("District", text="District")
            tree.heading("Votes", text="Votes")

            # Define column widths
            tree.column("Name", width=200)
            tree.column("Party", width=150)
            tree.column("District", width=150)
            tree.column("Votes", width=100)

            # Insert the results into the treeview
            for result in results:
                tree.insert("", "end", values=result)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch results: {str(e)}")
#Buttons
    ttk.Button(root, text="View Results", style="SoftRound.TButton", command=view_results).pack(pady=20)
    ttk.Button(root, text="Update Profile", style="SoftRound.TButton", command=lambda: update_user_profile(user_id)).pack(pady=20)
    ttk.Button(root, text="Back", style="SoftRound.TButton", command=lambda: open_page('main_app.py')).pack(pady=20)
    root.mainloop()
# Example usage:
# voter_dashboard(user_id=1)
